<footer>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
            <!-- Copyright info -->
            <p class="copy center">Copyright &copy; 2021 |
             <a href="#">Online KUSUMNIBASH Restaurant Management System</a> </p>
      </div>
    </div>
  </div>
</footer> 