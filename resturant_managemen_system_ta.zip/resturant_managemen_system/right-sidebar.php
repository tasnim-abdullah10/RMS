<div class="col-md-3 col-lg-3 hideme">
    <!-- Widget -->
    <div class="widget">
        <!-- Widget title -->
        <div class="widget-head">
            <div class="pull-left">Contact Information</div>

            <div class="clearfix"></div>
        </div>
        <div class="widget-content">
            <!-- Widget content -->
            <div class="padd">
                <!-- Contact box -->
                <div class="support-contact">
                    <!-- Phone, email and address with font awesome icon -->

                    <p><i class="fa fa-phone"></i>&nbsp; Phone<strong>:</strong> 01717-141414</p>
                    <hr />

                    <p><i class="fa fa-envelope"></i>&nbsp; Gmail<strong>:</strong>foodcourt@gmail.com</p>
                    <hr />
                    <p><i class="fa fa-home"></i>&nbsp; Address<strong>:</strong> Ashulia, Savar,Dhaka </p>
                    <hr />
                    <p><i class="fa fa-facebook"></i>&nbsp; Facebook<strong>:</strong> facebook.com/foodcourt </p>
                    <hr />
                    <!-- Button -->

                </div>
            </div>
        </div>

    </div>

</div>
</div>
</div>
</div>